NIM : 6706213064

NAMA : Zulfi Muhamad Briza Alghifari

KELAS : D3 RPLA 45-04